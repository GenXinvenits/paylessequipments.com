<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/admin-auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: /admin/');
  exit;
}
admin_verify_csrf();
$_SESSION = [];
if (ini_get('session.use_cookies')) {
  $params = session_get_cookie_params();
  setcookie(session_name(), '', [
    'expires' => time() - 42000,
    'path' => $params['path'],
    'domain' => $params['domain'],
    'secure' => $params['secure'],
    'httponly' => $params['httponly'],
    'samesite' => 'Strict',
  ]);
}
session_destroy();
header('Location: /admin/login.php');
exit;
