<section class="page-hero page-hero--contact"><div class="container page-hero__inner"><p class="eyebrow"><span class="eyebrow-line"></span> CONTACT / LET'S GET TO WORK</p><h1>Need equipment for<br><span>your next job?</span></h1><p>Tell us what you're working on and what equipment or delivery you need. We'll review your request and follow up with availability, pricing and next steps.</p><div class="contact-direct"><a href="tel:<?= e(SITE_PHONE_LINK) ?>"><?= e(SITE_PHONE) ?> ↗</a><span><?= e(SITE_ADDRESS) ?></span></div></div></section>
<section class="section contact-section"><div class="container contact-layout"><div class="contact-sidebar"><p class="eyebrow"><span class="eyebrow-line"></span> GET IN TOUCH</p><h2>Clear details.<br><span>Better next steps.</span></h2><p>For equipment requests, include the machine, rental period and job-site location. For gravel delivery, include material needs and the delivery address.</p><div class="contact-info"><span>PHONE</span><a href="tel:<?= e(SITE_PHONE_LINK) ?>"><?= e(SITE_PHONE) ?> ↗</a></div><div class="contact-info"><span>LOCATION</span><p><?= e(SITE_ADDRESS) ?></p><a href="https://maps.google.com/?q=4480+SW+185th+Ave+Beaverton+OR+97078" target="_blank" rel="noopener">Get directions ↗</a></div></div>
<div class="contact-form-wrap"><div class="contact-tabs"><a href="#equipment-request" class="is-active">EQUIPMENT REQUEST</a><a href="#gravel-request">GRAVEL DELIVERY</a></div>

<form class="request-form contact-form" id="equipment-request" action="/request.php" method="post">
  <input type="hidden" name="form_type" value="equipment">
  <div class="form-heading"><span>EQUIPMENT / REQUEST</span><span class="form-required">* REQUIRED</span></div>
  <fieldset class="equipment-choice">
    <legend>Equipment needed <em>*</em></legend>
    <details class="equipment-picker">
      <summary><span data-equipment-summary>Choose equipment</span><span class="equipment-picker__chevron" aria-hidden="true">⌄</span></summary>
      <div class="equipment-picker__options">
        <?php foreach ($equipment as $item): ?><label class="equipment-picker__option"><input type="checkbox" name="equipment[]" value="<?= e($item['name']) ?>" data-equipment-option><span><?= e($item['name']) ?></span></label><?php endforeach; ?>
        <label class="equipment-picker__option"><input type="checkbox" name="equipment[]" value="Other / not sure" data-equipment-option><span>Other / not sure</span></label>
      </div>
    </details>
    <small class="field-error" data-equipment-error hidden>Please select at least one equipment option.</small>
  </fieldset>
  <div class="form-row"><label>Rental period <em>*</em><select name="rental_period" required><option value="">Choose period</option><option>Daily</option><option>Weekly</option><option>Monthly</option><option>Not sure yet</option></select></label><label>Start date<input type="date" name="start_date"></label></div>
  <label>Job-site location <em>*</em><input name="job_location" required placeholder="Street, city or ZIP code"></label>
  <label>Project details<textarea name="details" rows="3" placeholder="Project type, access, attachments or delivery needs"></textarea></label>
  <div class="form-row"><label>Name <em>*</em><input name="name" required autocomplete="name"></label><label>Company<input name="company" autocomplete="organization"></label></div>
  <div class="form-row"><label>Phone <em>*</em><input type="tel" name="phone" required autocomplete="tel"></label><label>Email <em>*</em><input type="email" name="email" required autocomplete="email"></label></div>
  <label class="consent"><input type="checkbox" name="contact_consent" value="yes" required><span>I agree that PayLess may contact me about this request.</span></label>
  <button class="button button--primary button--wide" type="submit">Send equipment request <span>↗</span></button>
  <p class="form-disclaimer">This request does not reserve equipment. Availability and final pricing are confirmed by PayLess.</p>
</form>
<form class="request-form contact-form gravel-request-form" id="gravel-request" action="/request.php" method="post"><input type="hidden" name="form_type" value="gravel"><div class="form-heading"><span>GRAVEL / DELIVERY</span><span class="form-required">* REQUIRED</span></div><label>Delivery address / ZIP <em>*</em><input name="job_location" required placeholder="Where should gravel be delivered?"></label><div class="form-row"><label>Estimated quantity<input name="quantity" placeholder="e.g. 10 cubic yards"></label><label>Needed by<input type="date" name="start_date"></label></div><label>Project details<textarea name="details" rows="3" placeholder="Material, access, timing and any other details"></textarea></label><div class="form-row"><label>Name <em>*</em><input name="name" required autocomplete="name"></label><label>Company<input name="company" autocomplete="organization"></label></div><div class="form-row"><label>Phone <em>*</em><input type="tel" name="phone" required autocomplete="tel"></label><label>Email <em>*</em><input type="email" name="email" required autocomplete="email"></label></div><label class="consent"><input type="checkbox" name="contact_consent" value="yes" required><span>I agree that PayLess may contact me about this request.</span></label><button class="button button--primary button--wide" type="submit">Request gravel pricing <span>↗</span></button><p class="form-disclaimer">Delivery availability and pricing depend on location, material and quantity.</p></form>
</div></div></section>
